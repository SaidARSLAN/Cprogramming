#include <iostream>
#include <stdio.h>
#include <math.h>
using namespace std;
int fonk(int x,int n);
int fact(int y);
int main () {
	int x,n,i,a,toplam1=0,toplam2=0,m;
	cout<<"Lutfen x degerini gir: ";
	cin>>x;
	try {
	cout<<"Lutfen n degerini gir: ";
	cin>>n;
	if (n==0) throw 1;
	
	for(i=1;i<=n;i++) {
		if (i%2==0) {
			toplam1 = toplam1 + fonk(x,i);	
		}
		else {
			toplam2=toplam2+fonk(x,i);
		}	
	
	}
	}
	catch (int a) {
		cout<<a<<"HATA";
	}
	m=toplam2-toplam1;
	cout<<m;
	cout<<"\n";





}
int fact(int y) {
	if (y == 0) return 1;	
	return y * fact(y-1);



}

int fonk(int a,int b) {
	int c;
	c=(pow(a,b)/fact(b));
	return c;
}

