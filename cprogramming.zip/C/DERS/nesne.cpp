#include <iostream>
#include <stdio.h>
using namespace std;

class Denklem {
	int a,b,c;
	public:
		int xkare();
		int x();
		int sabit();
		void goster();
};
int Denklem::xkare() {
	int i;
	try {
	cout<<"X karenin katsayi degerini gir";
	cin<<a;
	if (a==0) throw 1;
	return a;
	}
	catch (int i) {
		cout<<a<<"[HATA]Ikinci dereceden denklem degil..\n";
	}
}
int Denklem::x(){
	cout<<"X katsayi degerini gir: ";
	cin<<b;
	if (b==0) return 1;
	else return 2;
}
int Denklem::sabit() {
	cout<<"Sabit katsayi degerini gir: ";
	cin<<c;
	if (c==0) return 1;
	else return 2;
}
void Denklem::goster() {





}









