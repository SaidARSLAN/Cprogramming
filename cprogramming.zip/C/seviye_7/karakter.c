#include <stdio.h>
#include <stdlib.h>
#define max 40
int boy(char dizi[]);
int main () {
	printf("\n[SECENEKLER]\n1-)Uzunluklari Olc\n2-)Tersten Okut\n3-)Ortak Harfleri Say\n");
	char dizi[max];
	char name[max];
	int choice;
	printf("[Cumle]==> ");
	fgets(dizi,max,stdin);
	printf("[Name]==> ");
	fgets(name,max,stdin);
	printf("[Ismin boyutu]==> %d\n",boy(name));
	printf("[Cumlenin boyutu]==> %d\n",boy(dizi));
	printf("[Secenek]==> ");
	scanf("%d",&choice);
	if(choice==1) {
		if(boy(name)==boy(dizi)) printf("Ikıside birbirine esit.\n");
		else {
			if(boy(name)-boy(dizi)<0) printf("%d  karakter eksik\n",-1*(boy(name)-boy(dizi)));
			else if (boy(dizi)-boy(name)<0) printf("%d karakter eksik\n",(boy(name)-boy(dizi)));
		}
	}
	else if (choice==2) {
		printf("[Tersten okut]");
		char ters[40];
		char ters2[40];
		int i;
		int j=boy(dizi)-1;
		for(i=0;dizi[i]!='\0';i++) {
			ters[i] = dizi[j];
			j--;
		}
		printf("\n[TERS]==> ");
		for(i=0;i<boy(dizi);i++) printf("%c",ters[i]);
		printf("\n");
		j=boy(name)-1;
		for(i=0;name[i]!='\0';i++) {
			ters2[i] = name[j];
			j--;
		}
		printf("[TERS]==> ");
		for(i=0;i<boy(name);i++) {
			printf("%c",ters2[i]);
		}
		printf("\n");
	
	}
	else if (choice==3) {
		int ortak_harfler[max]={0};
		int i;
		char encok;
		char harf
		while(cumle[i]) {
			if (cumle[i]>='a' && cumle[i]<='z') {
				ortak_harfler[cumle[i]-'a']++;
			}
		i++;
		}
		encok=ortak_harfler[0];
		for(i=1;i<26;i++) {
			if (ortak_harfler[i]!=0) {
				if(ortak_harfler[i]>encok) {
					encok=ortak_harfler[i];
					harf=i+'a';
				}
			}
		}
		printf("%c\n",harf);
	}	
	else {
		printf("Gecersiz Secim...\n");
	}
	return 0;
}
int boy(char dizi[]) {
	int i,sayac=0;
	for(i=1;dizi[i]!='\0';i++) {
		if (dizi[i]==' ') sayac--;
		sayac++;
	}
	return sayac;
}
