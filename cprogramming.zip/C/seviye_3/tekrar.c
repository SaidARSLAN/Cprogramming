#include <stdio.h>
#include <string.h>
int main () {
	char cumle[150];
	int i=0;
	int encok;
	char harf;
	//Baslangic degerini sifira esitledik.
	int kucukharf[26]={0};
	printf("[Cumle]==>");
	fgets(cumle,150,stdin);
	while(cumle[i]) {
		if(cumle[i] >= 'a' && cumle[i]<='z') {
		
			kucukharf[cumle[i] - 'a']++;
		}	
	i++;	
	}	
	encok=kucukharf[0];
	for(i=1;i<26;i++) {
		if (kucukharf[i] != 0) {
			if (kucukharf[i]>encok) {
				encok=kucukharf[i];
				harf=i+'a';
			}	
		}
	}
	printf("En fazla kullanilan harf %c'dir...\n",harf);
	return 0;
}
