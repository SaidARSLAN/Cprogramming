#include <stdio.h>
#include <string.h>
int main () {
	char cumle[100];
	printf("Cumle==> ");
	fgets(cumle,100,stdin);
	int i,j;
	for (i=0;i<strlen(cumle);i++) {
		for (j=0;j<=i;j++) {
			printf("%c ",cumle[j]);
		}
		printf("\n");
	
	}
	return 0;
}
