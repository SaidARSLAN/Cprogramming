#include <stdio.h>
#define MAX 40
void cumle_gir(char cumle[MAX]);
void bosluk_kaldir(char cumle[MAX]);
void tersine_cevir(char cumle[MAX], char ters[MAX]);
int dizinin_boyu(char cumle[MAX]);
int palindrome(char cumle[MAX]);

int main () {
	int a;
	char cumle[MAX];
	cumle_gir(cumle);
	a = palindrome(cumle);
	if (a==1) printf("Cumle palendromdur...\n");
	else printf("Cumle palendrom degildir...\n");
	return 0;
}
void cumle_gir(char cumle[MAX]) {
	int i=0;
	printf("[CUMLE]==> ");
	//Hatirlatma==> ilk karaktere ilk char degerini girdik..
	scanf("%c",&cumle[i]);
	//Hatirlatma==> buradaki dongunun mantigi dizinin icinde gezen i alt satira gidene kadar dongu calisacak demektir.
	while ((cumle[i] != '\n') && i<MAX) {
		i++;
		scanf("%c",&cumle[i]);
	}
	cumle[i]='\0';
}
//Hatirlatma==> buradaki mantik cumlenin icinde gezen i bosluga denk gelince kosula bagli olarak girmiyecek ve j bir artacak
//ardindan j ile arttirarak bellege kaydettigimiz karakter dizisi bu sayede birlesmis olacak.
//sonucta kayit ederken i veya jnin bir onemi yoktur.bellekte tutulan yerin onemi vardir.
void bosluk_kaldir(char cumle[MAX]) {
	int i,j=0;
	for (i=0;cumle[i]!='\0';i++) {
		if (cumle[i]!=' ') {
			cumle[j]=cumle[i];
			j++;
		}
	}
	cumle[j]='\0';
	for (i=0;cumle[i]!='\0';i++) {
		printf("%c",cumle[i]);
	
	}
}
int dizinin_boyu(char cumle[MAX]) {

	int i;
	for (i=0;cumle[i]!='\0';i++);
	return i;


}
void tersine_cevir(char cumle[MAX],char ters[MAX]) {
	int i;
	int j=dizinin_boyu(cumle)-1;
	for(i=0;cumle[i]!='\0';i++) {
		ters[i] = cumle[j];
		j--;
}
	printf("\nTERS DIZI==> ");
	for (i=0;i<dizinin_boyu(ters);i++) printf("%c",ters[i]);
	printf("\n");
	}
int palindrome(char cumle[MAX]) {
	int L,test;
	int i;
	char gecici[MAX];
	bosluk_kaldir(cumle);
	L = dizinin_boyu(cumle);
	tersine_cevir(cumle,gecici);
	for (i=0;i<L;i++) {
	
	if (gecici[i]!=cumle[i]) test=0;
	else test=1;
	return test;
	}
}
