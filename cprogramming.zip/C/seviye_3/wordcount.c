#include <stdio.h>
#include <stdlib.h>
int main () {

	char cumle[100];
	printf("Cumle==> ");
	fgets(cumle,100,stdin);
	printf("%s",cumle);
	int i,sayac=0;
	while(cumle[i]) {
		if (cumle[i] == 32) sayac++;
		i++;
	}
	printf("%d\n",sayac+1);
	return 0;
}
