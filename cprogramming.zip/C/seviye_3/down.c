#include <stdio.h>

int main () {
	char cumle[100];
	printf("Cumle==>");
	fgets(cumle,100,stdin);
	printf("%s",cumle);
	int i;
	while(cumle[i]) {
		printf("%c",cumle[i]);		
		if (cumle[i]==32) printf("\n"); 
		i++;
	}

	return 0;
}
