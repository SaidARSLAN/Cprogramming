#include <stdio.h>
#define MAX 40
void cumle_gir(char cumle[MAX]);
void karakter_say(char cumle[MAX]);
void bosluk_kaldir(char cumle[MAX]);
void ters_cevir(char cumle[MAX]);
int main () {
	char cumle[MAX];
	cumle_gir(cumle);
	karakter_say(cumle);
	bosluk_kaldir(cumle);
	ters_cevir(cumle);
	return 0;
}
void cumle_gir(char cumle[MAX]) {
	int i=0;
	printf("[CUMLE]==> ");		
	scanf("%c",&cumle[i]);
	while ((cumle[i] != '\n') && i<MAX ) {
		i++;
		scanf("%c",&cumle[i]);
	}
	cumle[i]='\0';
	printf("[%s]\n",cumle);
}

void karakter_say (char cumle[MAX]) {

	int i,sayac=0;
	for (i=0;cumle[i];i++) {
		if (cumle[i] == 32) sayac-=1;	
		sayac++;
	
	}
	printf("[%d]\n",sayac);
}
void bosluk_kaldir(char cumle[MAX]) {
	int i=0,sayac=0;
	while(cumle[i]) {
		if (cumle[i] == ' ' )
			cumle[i]=cumle[i+32] ;
			
	i++;
	}
	printf("[>> %s <<]\n",cumle);

}
void ters_cevir(char cumle[MAX]) {
	int i;
	for (i=0;i<=karakter_say(cumle);i++) {

		
			
	}
	printf("%s\n",cumle);

}
