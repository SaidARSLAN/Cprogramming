#include <stdio.h>

int main () {
	int a,b,c,x,sonuc;
	printf("lutfen a,b,c,x degerlerini giriniz...");
	scanf("%d%d%d%d",&a,&b,&c,&x);
	sonuc = (a * x * x + b * x + c);
	printf("Denklemin sonucu: %d",sonuc);

	return 0;
}
