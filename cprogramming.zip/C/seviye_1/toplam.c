#include <stdio.h>

int main () {

	int x;
	printf("sayi: ");
	scanf("%d",&x);
	int toplam = 0;
	int i=1;
	while (i<=x) {
		if (i==x) printf("%d",x);
		else {
			printf("%d + ",i);
		
		}
		toplam = toplam + i;
		i++;
	
	}
	printf(" = %d\n",toplam);

	return 0;
}
