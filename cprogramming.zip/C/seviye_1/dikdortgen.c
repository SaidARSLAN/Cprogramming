#include <stdio.h>

int main () {

	int a,b,h;
	printf("Dikdortgen degerlerini girin: ");
	scanf("%d%d%d",&a,&b,&h);
	int taban_alani = a * b;
	int yanal_alanlar = 2*a*h+2*b*h;
	int toplam_alan = taban_alani + yanal_alanlar;
	int hacim = a * b * h;
	printf("Taban Alani : %d\nYanal Alanlar: %d\n Toplam Alan: %d\nHacim: %d\n",taban_alani,yanal_alanlar,toplam_alan,hacim);


	return 0;
}
