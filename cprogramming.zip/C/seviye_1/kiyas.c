#include <stdio.h>

int main () {
	int a,b;
	printf("İki sayi girin\n");
	scanf("%d%d",&a,&b);
	if (a==b) printf("sayilar esit\n");
	if (a!=b) printf("sayilar esit degil\n");
	if (a>b)  printf("ilk sayi ikinciden buyuk\n");
	if (a<b)  printf("ikinci sayi birinciden buyuk\n");
	if (a%b==0) printf("sayilar birbirini kati\n");



	return 0;
}
