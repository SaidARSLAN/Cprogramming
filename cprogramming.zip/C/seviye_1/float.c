#include <stdio.h>

int main () {

	float x;
	printf("Bir x degeri gir: ");
	scanf("%f",&x);
	printf(">> f(%.3f) = %.3f\n",x,x*x*x+13*x*x+47*x+5);


	return 0;
}
