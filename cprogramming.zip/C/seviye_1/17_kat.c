#include <stdio.h>

int main () {

	int limit,satir=0;
	printf("Bir limit belirle: ");
	scanf("%d",&limit);
	int i=0;
	while (i<=limit) {
	
		if (i % 17 == 0) 
		{	
			if (satir % 10 == 0) {printf("\n");
			
			}
			satir++;
			printf("%4d",i);
		
		
		}
i++;
		}
	printf("\n");



	return 0;
}
