#include <stdio.h>

void us_al(int sayi, int us);



int main () {
	int sayi,us;
	printf("sayi==> ");
	scanf("%d",&sayi);
	printf("us==> ");
	scanf("%d",&us);
	us_al(sayi,us);

	return 0;
}

void us_al(int sayi, int us) {

	int i=1,sonuc=1;
	while(i<=us) {
		sonuc = sayi*sonuc;
		i++;
	}
	printf("%d\n",sonuc);
}
