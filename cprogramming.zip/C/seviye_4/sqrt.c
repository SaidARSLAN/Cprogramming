#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
void sqrtq(int *dizi,int n);
int main () {
	int n,i;
	printf("Dizi kac elemanli olsun: ");
	scanf("%d",&n);
	int dizi[n];
	srand((time(0)));
	for(i=0;i<n;i++) {
		dizi[i] = rand() % 10;
	}
	for(i=0;i<n;i++) {
		printf("%3d",dizi[i]);
	}
	printf("\n");
	sqrtq(dizi,n);
	return 0;
}
void sqrtq(int *dizi,int n) {
	int i;
	float hesap;
	for(i=0;i<n;i++) {
		hesap=0;
		hesap =  pow(dizi[i],0.5);
		printf("%4f",hesap);
	}
	printf("\n");
}
