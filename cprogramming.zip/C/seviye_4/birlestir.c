#include <stdio.h>
#include <stdlib.h>
#include <time.h>
void birles(int *dizi1,int *dizi2,int *dizi3,int n,int k,int c);
int main () {
	int n,k,i;
	printf("ilk dizi kac eleman olsun: ");
	scanf("%d",&n);
	int dizi1[n];
	srand((time(0)));
	for (i=0;i<n;i++) {
		dizi1[i] = rand() % 100;
	}
	for(i=0;i<n;i++) {
		printf("%3d",dizi1[i]);
		}
	printf("\n");
	printf("ikinci dizi kac elemanli olsun: ");
	scanf("%d",&k);
	int dizi2[k];
	for(i=0;i<k;i++) {
		dizi2[i] = rand() % 100;
	}
	for (i=0;i<k;i++) {
		printf("%3d",dizi2[i]);
	}
	printf("\n");
	int c=n+k;
	int dizi3[c];
	birles(dizi1,dizi2,dizi3,n,k,c);
	printf("ucuncu dizi\n");
	for (i=0;i<n+k;i++) {
		printf("%3d",dizi3[i]);
	}
	printf("\n");
	return 0;
}
void birles(int *dizi1,int *dizi2,int *dizi3,int n,int k,int c) {
	int i,j,sayac=0;
	for (i=0;i<n;i++) {
		dizi3[sayac] = dizi1[i];
		sayac++;
	}
	for (j=0;j<k;j++) {
		dizi3[sayac] = dizi2[j];
		sayac++;
	}
}
