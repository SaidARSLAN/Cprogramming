#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void max(int dizi[],int n);
void min(int dizi[],int n);
int main () {
	int n,i;
	printf("Kac karater dizi==> ");
	scanf("%d",&n);
	int dizi[n];
	srand((time(0)));
	for (i=0;i<n;i++) {
		dizi[i]=rand()%100;
		printf("%d\n",dizi[i]);
	}
	max(dizi,n);
	min(dizi,n);
	return 0;
}
void max (int dizi[], int n) {
	int i=0,max;
	max = dizi[i];
	for (i=0;i<n;i++) {
		if (dizi[i]>max) max = dizi[i];
	}
	printf("\n%d\n",max);


}
void min (int dizi[],int n) {
	int i=0,min;
	min = dizi[i];
	for (i=0;i<n;i++) {
		if (dizi[i]<min) min = dizi[i];
	}
	printf("%d\n",min);
}
