#include <stdio.h>
void fact(int sayi);
int main () {
	int sayi;
	printf("Sayi==> ");
	scanf("%d",&sayi);
	fact(sayi);



	return 0;
}

void fact(int sayi) {

	int i=1,carpim=1;
	while(i<=sayi) {
	
		carpim=carpim*i;
		i++;
	}
			
	
	printf("%d\n",carpim);
}

