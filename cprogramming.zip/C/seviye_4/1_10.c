#include <stdio.h> 
int fact(int sayi);
int main () {
	int i;
	for (i=0;i<=10;i++) {
		printf("%d! => %d\n",i,fact(i));
		
	}

	return 0;
}

int fact(int sayi) {

	int i,fact=1;
	for (i=1;i<=sayi;i++) {
		fact = fact*i;
		
	}
	return fact;
}
