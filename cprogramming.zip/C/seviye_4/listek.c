#include <stdio.h>
void liste(int sayi);
int main () {

	int sayi;
	printf("sayi==> ");
	scanf("%d",&sayi);
	liste(sayi);
	return 0;
}
void liste(int sayi) {

	int i;
	for (i=1;i<=sayi;i++) {
		if (i%2 ==0) continue;
		printf("%4d",i);
	
	}
}
