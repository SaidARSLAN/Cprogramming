#include <stdio.h>

void ust_taraf(int n);
void alt_taraf(int n);
int main () {
	int giris;
	printf("Kac satir: ");
	scanf("%d",&giris);
	ust_taraf(giris);
	alt_taraf(giris);
	return 0;
}
void ust_taraf(int n) {
	int i,j;
	int bosluk= n-1;
	for(i=1;i<n;i++){
		for(j=1;j<=bosluk;j++) {
			printf(" ");
		}
		bosluk--;
		for(j=1;j<=2*i-1;j++) {
			printf("c");
		}
		printf("\n");
	}
}
void alt_taraf(int n) {
	int i,j;
	int bosluk=0;
	for(i=1;i<n;i++) {
		for(j=0;j<=bosluk;j++) {
			printf(" ");
		}
		bosluk++;
	for(j=1;j<=2*(n-i)-1;j++) {
		printf("*");
	}
		printf("\n");
	}
}	
