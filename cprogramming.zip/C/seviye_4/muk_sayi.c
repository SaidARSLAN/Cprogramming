#include <stdio.h>
void bul(int sayi);
int main () {
	int sayi;
	printf("sayi gir: ");
	scanf("%d",&sayi);
	bul(sayi);
	
	return 0;
}
void bul (int sayi) {
	int i,toplam =0;
	for (i=1;i<sayi;i++) {
		if (sayi % i == 0) {
			toplam = toplam + i;
		}
	}
	if (toplam == sayi) {
		printf("muk..\n");
		}
	
}
