#include <stdio.h>
void fibo(int girdi);
int main () {
	int girdi;
	printf("Girdi==> ");
	scanf("%d",&girdi);
	fibo(girdi);
	


	return 0;
}
void fibo(int girdi) {

	int i=1,j=1,sayac=0;
	int gecici;
	for (;sayac<girdi;sayac++) {
		gecici=j;
		j=j+i;
		i=gecici;
		printf("%4d",j);
	}
		
	

}
