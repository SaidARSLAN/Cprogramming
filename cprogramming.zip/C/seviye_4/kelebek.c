#include <stdio.h>
void sekil_ciz(int n,char c);
int main () {
	int n;
	char c;
	printf("Karakter: ");
	scanf("%c",&c);
	printf("Kenar sayisi: ");
	scanf("%d",&n);
	sekil_ciz(n,c);
}
void sekil_ciz(int n,char c) {
	int i,j;
	for(j=n;j>0;j--) {
		for(i=1;i<=n-j;i++) {
			printf(" ");
		}
	for(i=1;i<=2*j-1;i++) {
		printf("%c",c);
	}	
	printf("\n");
	}
	for(j=1;j<=n;j++) {
		for(i=1;i<=n-j;i++) {
			printf(" ");
		}
	for(i=1;i<=2*j-1;i++) {
		printf("%c",c);
	}
	printf("\n");
	}	

}
