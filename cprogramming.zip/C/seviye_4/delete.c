#include <stdio.h>
#include <stdlib.h>
#include <time.h>
void delete(int dizi[],int n,int x);
int main () {

	int n,i,x;
	printf("Kac adet sayi üretilsin: ");
	scanf("%d",&n);
	int dizi[n];
	srand((time(NULL)));
	for (i=0;i<n;i++) {
		dizi[i] = rand() % 25;
		printf("[%d]\n",dizi[i]);
	}
	printf("Kacinci eleman silinecek: ");
	scanf("%d",&x);
	delete(dizi,n,x);
	return 0;
}
void delete(int dizi[],int n,int x) {
	int i;
	if (x>=n+1) printf("Lutfen gecerli bir sira numarasi girin\n");		
	else { 
		for (i=x-1;i<n-1;i++)	
		{
			dizi[i]=dizi[i+1];
		}
		printf("Silindikten sonraki durum...\n");
		printf("[");
		for(i=0;i<n-1;i++) {
		printf("%d,",dizi[i]);
	}
		printf("]\n");		
	}
}

