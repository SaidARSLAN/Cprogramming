#include <stdio.h>
void floyd(int satir);
int main () {

	int satir;
	printf("Satir==> ");
	scanf("%d",&satir);
	floyd(satir);


	return 0;
}

void floyd(int satir) {

	int i=1,j;
	int a=1;
	while(i<=satir) {
		j=1;
		while(j<=i) {
			printf("%4d",a);
			a++;		
			j++;
		}
		printf("\n");
		i++;
	
	}	
	
	printf("\n");
}


