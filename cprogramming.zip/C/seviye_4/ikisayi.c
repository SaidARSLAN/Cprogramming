#include <stdio.h>
void bul (int x, int y);
int main () {

	int x,y;
	printf("sayilari gir...\n");
	scanf("%d%d",&x,&y);
	bul(x,y);


	return 0;
}
void bul (int x, int y) {
	int z=x;
	if (x>y) printf("%d",x);
	
	else printf("%d",y);
}
