#include <stdio.h>
#define max 1000
void girdi_al();
int main () {

	girdi_al();
		


	return 0;
}
void girdi_al() {
		int girdi;
		while(1) {
			printf("Girdi==> ");
			scanf("%d",&girdi);
			if (girdi <0 ) break;
		
		}	

}


	

