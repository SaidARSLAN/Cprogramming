#include <stdio.h>
#include <stdlib.h>
#include <time.h>
void sira(int *dizi,int n);
int main () {
	int n,i;
	printf("Kac satirlik dizi olussun: ");
	scanf("%d",&n);
	int dizi[n];
	srand((time(0)));
	for(i=0;i<n;i++) {
		dizi[i] = rand() % 100;
	}
	printf("[bas,");
	for (i=0;i<n;i++) {
		printf("%d,",dizi[i]);
	}
	printf("son]\n");
	sira(dizi,n);
	return 0;
}
void sira(int *dizi,int n) {
	int i,j;
	int gecici;
	for (i=0;i<=n;i++) {
		for(j=1;j<=n;j++){
		if (dizi[j]>=dizi[j+1]) {
			gecici=dizi[j+1];
			dizi[j+1] = dizi[j];
			dizi[j] = gecici;	
		}
	}
	}
	printf("[bas,");
	for(i=0;i<n;i++) {
		printf("%d,",dizi[i]);
	}
	printf("son]\n");

}
