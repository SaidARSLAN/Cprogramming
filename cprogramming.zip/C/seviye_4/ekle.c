#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void ekle(int *dizi,int n, int sayi, int x);

int main () {
	int n,i,sayi,x;
	printf("Kac sayilik dizi olsun==> ");
	scanf("%d",&n);
	int dizi[n];
	printf("Dizi olusturuluyor...\n");
	srand((time(0)));
	for (i=0;i<n;i++) {
		dizi[i] = rand() % 25;
	}
	for (i=0;i<n;i++) {
		printf(" %d ",dizi[i]);
	}
	printf("\n");
	printf("Sayi==> ");
	scanf("%d",&sayi);
	printf("Kacinci siraya eklemek istersin");
	scanf("%d",&x);
	ekle(dizi,n,sayi,x);
	return 0;
}

void ekle(int *dizi,int n,int sayi,int x) {
	int i,j;
	int gecici;
	for(i=n-1;i>=x-1;i--) {
		dizi[i+1] = dizi[i];	
	}
	dizi[x-1]=sayi;
	

	for(i=0;i<=n;i++) {
	printf("%d\n",dizi[i]);
	}

}
