#include <stdio.h>
#include <stdlib.h>
int hesap(int sayi1,int sayi2,char op);



int main () {
	int sayi1,sayi2;
	char op;
	printf("Islem sec...");
	scanf("%c",&op);
	printf("Iki sayi girin...");
	scanf("%d",&sayi1);
	scanf("%d",&sayi2);
	printf("%d",hesap(sayi1,sayi2,op));
	return 0;
}

int hesap(int sayi1,int sayi2,char op) {

	if (op=='+')  	  return sayi1+sayi2;
	else if (op=='-') return sayi1-sayi2;
	else if (op=='*') return sayi1*sayi2;
	else if (op=='/') return sayi1/sayi2;
	else printf("gecersiz...\n");
}
