#include <stdio.h>
#include <string.h>
int main () {
	char cumle[100];
	int i,sayac=0;
	printf("Lutfen bir cumle girin: ");
	fgets(cumle,100,stdin);
	printf("%s",cumle);
	for (i=1;i<strlen(cumle);i++) {
		if (cumle[i]== ' ') sayac--;
		sayac++;
	}
	printf("%d\n",sayac);


	return 0;
}
