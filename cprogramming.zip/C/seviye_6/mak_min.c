#include <stdio.h>

int main () {
	int dizi[10];
	int n,i=0;
	int max;
	do{
		printf("%d.sayiyi gir: ",i+1);
		scanf("%d",&n);
		dizi[i]=n;
		i++;
	}
	while(i<10);
	max=dizi[0];
	for(i=0;i<10;i++) {
		if(dizi[i]>max) max=dizi[i];	
	}
	printf("Maksimum sayin: %d",max);

	return 0;
}
