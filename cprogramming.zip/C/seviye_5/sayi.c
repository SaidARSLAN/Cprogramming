#include <stdio.h>
#include <math.h>
int main () {
	int n,sonuc,i;
	do {
	printf("Lutfen bir sayi girin: ");
	scanf("%d",&n);
	if (n<0) printf("Lutfen pozitif bir sayi girin..\n");
	if (n==0) break;
	printf("Sonuc==> %lf\n",sqrt(n));
	}
	while (i>0);
	return 0;
}
