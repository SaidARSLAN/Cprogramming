#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
int main () {
	char karakter;
	printf("Lutfen bir isim girin: ");
	scanf("%c",&karakter);
	if((karakter>='A') && (karakter<='Z')) {
		printf("Kucuk harfimiz: %c\n",tolower(karakter));
	}
	else {
		printf("Yanlis..\n");
	}
	return 0;
}
