#include <stdio.h>

int main () {
	int i=1,n;
	float toplam;
	printf("Dizi nerede sonlansin: ");
	scanf("%d",&n);
	do{
	toplam=toplam+ (float) 1/i;
	printf("%2f\n",toplam);
	i++;
	}
	while(i<=n);

	return 0;
}
