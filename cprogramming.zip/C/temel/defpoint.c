#include <stdio.h>
#include <stdlib.h>

void kare(int *sonuc, int *can) {

	*sonuc=*can**can;
	//Burada bu olay sonuc degerini global yapar.

}


int main () {
	int x=4,karesi;
	int sonucum;

	kare(&sonucum,&x);
	printf("%d\n",sonucum);


	return 0;
}
