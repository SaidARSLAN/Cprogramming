#include <stdio.h>
#include <stdlib.h>
void us_al(int x,int y,int *sonuc) {

	*sonuc=1;
	int i;
	for (i=0;i<y;i++) {
	
		*sonuc = *sonuc*x;
	
	}


}


int main () {

	int x=4,y=5,sonuc;
	us_al(x,y,&sonuc);
	printf("%d\n",sonuc);


	return 0;
}
