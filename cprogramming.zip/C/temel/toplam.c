#include <stdio.h>

int main () {

	int dizi[5];
	int i,toplam=0;
	for(i=0;i<=5;i++) {
	
		printf("Bir sayi girin:");
		scanf("%d",&dizi[i]);
	}
	for (i=0;i<=5;i++) {
	
		printf("%d\n",toplam = toplam + dizi[i]);
	}
	printf("Son toplam=>> %d",toplam);
	return 0;
}
