#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main () {


	char dizi1[]="bonne";
	char dizi2[]="soiree";
	char sonuc[100]="";//Hata vermemesi icin boyle yazdık.
	strcpy(sonuc,dizi1);
	strncpy(sonuc+3,dizi2,4);
	printf("%s\n",sonuc);




	return 0;
}
