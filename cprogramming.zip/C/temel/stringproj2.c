#include <stdio.h>
#include <stdlib.h>

int main () {

	char dizi[100][100] = {"bir","iki","uc","dort","bes"};
	printf("dizimin dorduncu karakteri %s\n",dizi[3]);
	printf("dizimin dorduncu karakterinin ucuncu harfi %c\n",dizi[3][2]);


	return 0;
}
