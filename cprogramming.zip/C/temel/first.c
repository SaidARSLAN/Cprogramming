#include <stdio.h>
#include <stdlib.h>

int main () {
/*Bir degisken atamamız bellekte tutulan yer miktarini degistirmez.*/
	int tamsayi;
	char karakter;
	float ondaliksayi1;
	double ondaliksayi2;
	printf("char bellekte %lu byte kadar yer tutar.\n",sizeof(char));

	printf("char bellekte %lu byte kadar yer tutar.\n",sizeof(int));
	printf("char bellekte %lu byte kadar yer tutar.\n",sizeof(float));
	printf("char bellekte %lu byte kadar yer tutar.\n",sizeof(double));
	return 0;
}
