#include <stdio.h>

int main () {
	char can[]={'c','a','n','a','n','\0'};
	char dizim[]="canan";
	char kullanici[100];
	printf("%s\n",dizim);
	printf("Bir sey gir: ");
	scanf("%s",kullanici);
	printf("%s",kullanici);
	return 0;
}
