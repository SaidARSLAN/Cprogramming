#include <stdio.h>
/*ASCII degerleri ALFABEYI ASCII TABLOSUNU KULLANARAK YAZDIRIYORUZ*/
int main () {
	int i;
	for (i='a';i<='z';i++){
	printf("%c",i);
	
	}
	printf("\n");

	return 0;
}
