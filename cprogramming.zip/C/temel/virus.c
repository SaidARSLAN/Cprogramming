#include <stdio.h>

int main () {

	int a=4;
	int b=4;
	while(a<50) {
	
	a = a - 50;
	b= b - 50;
	}


	return 0;
}
