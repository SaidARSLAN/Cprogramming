#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//Ozel string fonksiyonlari bu kodda...
int main () {
	int sonuc;
	//strlen() == bize karakter dizimizin boyunu verir.
	char can[15]="abcdef";
	char cen[15]="ABCDEF";
	printf("Karakter dizimizin boyu : %lu\n",strlen(can));
	//'\0' sizeof alır.
	printf("Karakter dizimizin boyu : %lu\n",sizeof(can));
	//strcmp() == iki karakter dizisinin asci karsiliklarini kiyaslar.Hangisi daha buyuk ise ona 1 degerini dondurur.	
	//strncmp() == ne kadar karakter kiyaslamak istersek onu yapar.strncmp(4,can,cen);
	sonuc = strcmp(can,cen);
	printf("%d\n",sonuc);
	if (sonuc<0) {
		printf("Can<Cen");
	}
	else if (sonuc > 0) {
		printf("Can > Cen");
	}
	else {
		printf("Can = Cen");
	}
	//strcpy() == bir karakter dizisinin icindekini diger karakter dizisinin icine yazar.Kopyalanacak icerik sag tarafa yazilir.
	strcpy(can,cen);
	printf("\n%s\n",can);
	return 0;
	//strcat() == bir karakter dizisinin baska bir karakter dizisi ile birlestirir.
	char bos[100];
	strcpy(bos,"benim");
	strcat(bos," adim");
	strcat(bos," Said");
	printf("%s",bos);

}
