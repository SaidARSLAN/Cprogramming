#include <stdio.h>
int us_al(int x, int y) {

	int i,sonucum=1;
	for(i=0;i<y;i++) {
		sonucum = sonucum * x;	
	
	}
	return sonucum;

}




int main () {

	int x=4,y=5;
	int sonuc = us_al(x,y);
	printf("%d\n",sonuc);


	return 0;
}
