#include <stdio.h>


int main () {

	int no1,no2;
	char op;
	printf("bir operator girin (+,-): ");
	scanf("%c",&op);
	printf("ikiser sayi girin:\n");
	scanf("%d%d",&no1,&no2);
	if (no1==0 || no2==0) printf("islem gerceklestirilemez...\n");
	else {
		printf("1/%d %c 1/%d = ",no1,op,no2);
		switch (op) {
		
			case '+':
				printf("%d/%d\n",no1+no2,no1*no2);
				break;
		
			case '-':
				printf("%d/%d\n",no1-no2,no1*no2);
				break;
		}	
	
	}


 	return 0;
}
