#include <stdio.h>

int main () {
	float sure,sinir=3.0,ucret=0;
	printf("Konusulan sureyi girin: ");
	scanf("%f",&sure);
	if (sure <= sinir) ucret=0.25;
	else {
		ucret = 0.25 + (sure - 3)*0.08;
	
	}
	printf("%.2f",ucret);

}
	
