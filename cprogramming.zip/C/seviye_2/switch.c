#include <stdio.h>

int main () {
	int kod;
	float fiyat;
	printf("URUN KODU: ");
	scanf("%d",&kod);
	printf("Fiyat: ");
	scanf("%f",&fiyat);
	switch (kod) {
		case 1:
			printf("Kitap...\n");
			fiyat += fiyat * 4/100;
			printf("Son fiyat: %f",fiyat);		
			break;
		case 2:
			printf("Temel Gida...\n");
			fiyat += fiyat * 5.6/100;
			printf("Son fiyat: %f",fiyat);
			break;
		case 3:
			printf("Luks Urunler...\n");
			fiyat += fiyat * 19.6/100;
			printf("Son fiyat: %f",fiyat);
			break;
		default:
			printf("Dogru deger gir...\n");
			break;
	
	}



	return 0;
}
