#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define hedef 150
int main () {

	int boy,no,minimum_boy,minimum_no;
	int fark;
	printf("boy: ");
	scanf("%d",&boy);
	printf("no: ");
	scanf("%d",&no);
	minimum_no = no;
	fark = abs(boy - hedef);
	while (no>0) {
	
		printf("boy: ");
		scanf("%d",&boy);
		printf("no: ");
		scanf("%d",&no);
		if (abs(boy - hedef)<fark) {
			fark = abs(boy- hedef);
			minimum_boy = boy;
			minimum_no = no;
		}
	
	
	}
	printf("%d nolu ogrenci %d boy ile %d boyuna en yakin ogrencidir...\n",minimum_no,minimum_boy,hedef);
	return 0;
}
