#include <stdio.h>
#include <math.h>
int main () {
	int n,i;
	float x,seri;
	char devam;
	do {
	printf("n: ");
	scanf("%d",&n);
	printf("x: ve cevap: ");
	scanf("%f %c",&x,&devam);
	seri=0;
	for (i=1;i<=2 * n - 1; i = i + 2) {
		seri = seri + i/pow(x,i+1);	
	}
	printf("Seri = %f\n",seri);
	}
	while((devam == 'E') || (devam == 'e'));
	printf("hoscakalin...\n");
	return 0;
}
