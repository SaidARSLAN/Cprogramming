#include <stdio.h>

int main () {
/*BENIM KODUM
	char ch;
	printf("Lutfen bir harf girin: ");
	scanf("%c",&ch);
	int i,j=0,l,k=0;
	for (i='a';i<'z';i++) {
		j++;
		if (ch == i) printf("%c: %d.harftir.",ch,j);
	}
	for (l='A';l<'Z';l++) {
		k++;
		if (ch==l) printf("%c: %d.harftir.",ch,k);
	}
	printf("\n");
	*/
	char ch;
	int sira;
	printf("Karakter: ");
	scanf("%c",&ch);
	if ((ch>='A') && (ch<='Z'))
	{
	sira = (int)ch-(int)'A' + 1;
	}
	else if ((ch>='a') && (ch<='z')) {
	
		sira = (int)ch-(int)'a'+1;
	}
	else {
		printf("Boyle bir harf yok...\n");
	}
	printf("%c : %d. harftir.\n",ch,sira);












	return 0;
}
