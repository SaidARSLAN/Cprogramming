#include <stdio.h>
#define tavhiz 0.038
#define kushiz 0.012
int main () {
	/* BENIM KODUM
	int i,yil;
	float toplam_tavsan=1042.0,toplam_kus=2272.0;
	printf("Yil: ");
	scanf("%d",&yil);
	for (i=1;i<=yil;i++) {
		toplam_tavsan = toplam_tavsan + toplam_tavsan * (3.8/100);
	}
	printf("%.2f\n",toplam_tavsan);
	for (i=1;i<=yil;i++) {
		toplam_kus = toplam_kus + toplam_kus * (1.2/100);
		
	}
	printf("%.2f\n",toplam_kus);
	if (toplam_tavsan > toplam_kus ) {
		printf("%d yil sonra ancak tavsanlar kuslari gecer...\n",yil);
	
	}
	*/
	float tavsan=1042,kus=2272;
	int yil=0;
	while(tavsan<kus) {
		tavsan += tavsan*tavhiz;
		kus += kus*kushiz;
		yil++;
	}
	printf("%d. yilda tavsanlar kuslari gecer...\n",yil);
}
