#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main () {

	int n,i;
	float x,toplam;
	printf("n: ");
	scanf("%d",&n);
	printf("x: ");
	scanf("%f",&x);
	for (i=1;i<=2*n-1;i+=2) {
		toplam += i/pow(x,i+1);
	
	}
	printf("Toplam = %.2f\n",toplam);
	return 0;
}
